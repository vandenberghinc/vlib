# Cryptography
Cryptography.

## Compiling
Requires compiler flags: `-I /usr/local/opt/openssl@3/include/ -L /usr/local/opt/openssl@3/lib/ -lcrypto -lssl`. <br/>
The location of your `openssl` library may differ.
