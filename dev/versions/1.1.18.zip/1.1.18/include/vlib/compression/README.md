# Compression
Compression.

## Compiling
Requires compiler flags `-I /usr/local/opt/zlib/include -lz`. . <br/>
The location of your `zlib` library may differ.
