/*
 Author: Daan van den Bergh
 Copyright: © 2022 Daan van den Bergh.
*/

// Header.
#ifndef VLIB_FILE_H
#define VLIB_FILE_H

// Namespace vlib.
namespace vlib {

// Load a file.
// - Returns 0 on success, < 0 on failure.
// - The data buffer will be deleted, so by default it should be initialized with "nullptr".
// - The data buffer will always be deleted upon failure.
// - Max size of "len" is the max of a "ulong".
inline
int 	load(
	const char* 	path, 	// the file path.
	char*& 			data, 	// a reference to the data buffer, will be deleted before read (only for output).
	ullong&			len		// a reference to the length of the data buffer (only for output).
) {
	delete[] data;
	FILE *f = fopen(path, "rb");
	if (!f) {
		data = nullptr;
		return file::error::open;
	}
	fseek(f, 0, SEEK_END);
	len = (ullong) ftell(f);
	fseek(f, 0, SEEK_SET);
	data = new char [len + 1];
	if (fread(data, sizeof(char), len, f) != len) {
		delete[] data;
		data = nullptr;
		fclose(f);
		return file::error::read;
	}
	fclose(f);
	data[len] = '\0';
	return 0;
}

// Save a file.
// - Returns 0 on success, < 0 on failure.
// - Max size of "len" is the max of a "ulong".
inline
int 	save(
	const char* 				path, 	// the file path.
	const char*					data, 	// the data to save.
	const ullong&	len		// the data length.
) {
	FILE *f = fopen(path, "wb");
	if (!f) {
		return file::error::open;
	}
    if (len == 0) {
        fclose(f);
        return 0;
    }
	if (fwrite(data, len, 1, f) != 1) {
		fclose(f);
		return file::error::write;
	}
	fclose(f);
	return 0;
}

}; 		// End namespace vlib.
#endif 	// End header.
