# Global
Utility types & functions for the `vlib` namespace.
