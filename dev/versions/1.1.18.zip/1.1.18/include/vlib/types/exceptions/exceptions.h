/*
 Author: Daan van den Bergh
 Copyright: © 2022 Daan van den Bergh.
*/

// Header.
#ifndef VLIB_EXCEPTIONS_H
#define VLIB_EXCEPTIONS_H

// Namespace vlib.
namespace vlib {

// Namespace exceptions.
namespace exceptions {

// Create exception macro.
#define CREATE_EXCEPTION(name, strname) \
struct name : public vlib::exceptions::Exception { \
    static excid_t type_id; \
    name(const ullong& parent_id, const ullong& message_id) : \
    vlib::exceptions::Exception(type_id, parent_id, message_id) {} \
    template <typename String> \
    name(const char* parent, const String& message) : \
    vlib::exceptions::Exception(strname, parent, message) {} \
    template <typename String> \
    name(const char* parent, String&& message) : \
    vlib::exceptions::Exception(strname, parent, message) {} \
}; \
excid_t name::type_id = vlib::exceptions::add_type(strname); \

// Add exception to shortcuts macro.
#define SHORTCUT_EXCEPTION(name, full_name) \
namespace shortcuts { \
namespace exceptions { \
using name = full_name; \
}}

struct InvalidUsageError; CREATE_EXCEPTION(InvalidUsageError, "InvalidUsageError");
struct IndexError; CREATE_EXCEPTION(IndexError, "IndexError");
struct KeyError; CREATE_EXCEPTION(KeyError, "KeyError");
struct TypeError; CREATE_EXCEPTION(TypeError, "TypeError");
struct AllocError; CREATE_EXCEPTION(AllocError, "AllocError");

struct OSError; CREATE_EXCEPTION(OSError, "OSError");

struct PointerError; CREATE_EXCEPTION(PointerError, "PointerError");
struct CreateError; CREATE_EXCEPTION(CreateError, "CreateError");
struct RemoveError; CREATE_EXCEPTION(RemoveError, "RemoveError");
struct DeleteError; CREATE_EXCEPTION(DeleteError, "DeleteError");
struct AddError; CREATE_EXCEPTION(AddError, "AddError");
struct OpenError; CREATE_EXCEPTION(OpenError, "OpenError");
struct ReadError; CREATE_EXCEPTION(ReadError, "ReadError");
struct WriteError; CREATE_EXCEPTION(WriteError, "WriteError");
struct FlushError; CREATE_EXCEPTION(FlushError, "FlushError");
struct SyncError; CREATE_EXCEPTION(SyncError, "SyncError");
struct CopyError; CREATE_EXCEPTION(CopyError, "CopyError");
struct MoveError; CREATE_EXCEPTION(MoveError, "MoveError");
struct ScanError; CREATE_EXCEPTION(ScanError, "ScanError");
struct LinkError; CREATE_EXCEPTION(LinkError, "LinkError");
struct FileNotFoundError; CREATE_EXCEPTION(FileNotFoundError, "FileNotFoundError");
struct TimeoutError; CREATE_EXCEPTION(TimeoutError, "TimeoutError");
struct BufferOverflow; CREATE_EXCEPTION(BufferOverflow, "BufferOverflow");

struct DuplicateError; CREATE_EXCEPTION(DuplicateError, "DuplicateError");

struct ParseError; CREATE_EXCEPTION(ParseError, "ParseError");

struct EnvironmentError; CREATE_EXCEPTION(EnvironmentError, "EnvironmentError");

struct PermissionError; CREATE_EXCEPTION(PermissionError, "PermissionError");

struct InvalidGIDError; CREATE_EXCEPTION(InvalidGIDError, "InvalidGIDError");
struct InvalidUIDError; CREATE_EXCEPTION(InvalidUIDError, "InvalidUIDError");
struct GenerateUIDError; CREATE_EXCEPTION(GenerateUIDError, "GenerateUIDError");
struct SetPasswordError; CREATE_EXCEPTION(SetPasswordError, "SetPasswordError");
struct PromptPasswordError; CREATE_EXCEPTION(PromptPasswordError, "PromptPasswordError");

struct DimensionError; CREATE_EXCEPTION(DimensionError, "DimensionError");

struct ThreadError; CREATE_EXCEPTION(ThreadError, "ThreadError");
struct MutexError; CREATE_EXCEPTION(MutexError, "MutexError");
struct LockError; CREATE_EXCEPTION(LockError, "LockError");
struct UnlockError; CREATE_EXCEPTION(UnlockError, "UnlockError");
struct StartError; CREATE_EXCEPTION(StartError, "StartError");
struct JoinError; CREATE_EXCEPTION(JoinError, "JoinError");
struct DetachError; CREATE_EXCEPTION(DetachError, "DetachError");
struct SignalError; CREATE_EXCEPTION(SignalError, "SignalError");
struct KillError; CREATE_EXCEPTION(KillError, "KillError");

struct SerialError; CREATE_EXCEPTION(SerialError, "SerialError");

struct ShapeError; CREATE_EXCEPTION(ShapeError, "ShapeError");

struct GenerateSaltError; CREATE_EXCEPTION(GenerateSaltError, "GenerateSaltError");
struct GenerateIVError; CREATE_EXCEPTION(GenerateIVError, "GenerateIVError");
struct GenerateKeyError; CREATE_EXCEPTION(GenerateKeyError, "GenerateKeyError");
struct EncryptError; CREATE_EXCEPTION(EncryptError, "EncryptError");
struct DecryptError; CREATE_EXCEPTION(DecryptError, "DecryptError");

struct SignError; CREATE_EXCEPTION(SignError, "SignError");
struct HashError; CREATE_EXCEPTION(HashError, "HashError");

struct RSAError; CREATE_EXCEPTION(RSAError, "RSAError");

struct LimitError; CREATE_EXCEPTION(LimitError, "LimitError");
struct DeflateError; CREATE_EXCEPTION(DeflateError, "DeflateError");
struct InflateError; CREATE_EXCEPTION(InflateError, "InflateError");
struct CompressionError; CREATE_EXCEPTION(CompressionError, "CompressionError");

struct SocketError; CREATE_EXCEPTION(SocketError, "SocketError");
struct SetOptionError; CREATE_EXCEPTION(SetOptionError, "SetOptionError");
struct LookupError; CREATE_EXCEPTION(LookupError, "LookupError");
struct CloseError; CREATE_EXCEPTION(CloseError, "CloseError");
struct SocketClosedError; CREATE_EXCEPTION(SocketClosedError, "SocketClosedError");
struct PollError; CREATE_EXCEPTION(PollError, "PollError");
struct BindError; CREATE_EXCEPTION(BindError, "BindError");
struct ListenError; CREATE_EXCEPTION(ListenError, "ListenError");
struct AcceptError; CREATE_EXCEPTION(AcceptError, "AcceptError");
struct ConnectError; CREATE_EXCEPTION(ConnectError, "ConnectError");
struct BrokenPipeError; CREATE_EXCEPTION(BrokenPipeError, "BrokenPipeError");

struct RateLimitExceeded; CREATE_EXCEPTION(RateLimitExceeded, "RateLimitExceeded");

struct TLSError; CREATE_EXCEPTION(TLSError, "TLSError");
struct TLSVersionError; CREATE_EXCEPTION(TLSVersionError, "TLSVersionError");

struct SMTPError; CREATE_EXCEPTION(SMTPError, "SMTPError");

struct DaemonError; CREATE_EXCEPTION(DaemonError, "DaemonError");

struct ConfigError; CREATE_EXCEPTION(ConfigError, "ConfigError");

struct CudaError; CREATE_EXCEPTION(CudaError, "CudaError");

struct UserDoesNotExistError; CREATE_EXCEPTION(UserDoesNotExistError, "UserDoesNotExistError");

}; 		// End namespace exceptions.
}; 		// End namespace vlib.
#endif 	// End header.
