/*
 Author: Daan van den Bergh
 Copyright: © 2022 Daan van den Bergh.
*/

// Header.
#ifndef VLIB_EXCEPTION_T_H
#define VLIB_EXCEPTION_T_H

// Trace variable.
#ifndef vlib_enable_trace
#define vlib_enable_trace false
#endif

// Global xception id alias.
using excid_t = const unsigned long long;

// Namespace vlib.
namespace vlib {

// Namespace exceptions.
namespace exceptions {

// Static id arrays.
static char** type_ids = nullptr;
static ullong type_ids_len = 0;
static ullong type_ids_cap = 0;
static char** parent_ids = nullptr;
static ullong parent_ids_len = 0;
static ullong parent_ids_cap = 0;
static char** err_ids = nullptr;
static ullong err_ids_len = 0;
static ullong err_ids_cap = 0;

// Get ids.
auto& type(excid_t& id) {
    return type_ids[id];
}
auto& parent(excid_t& id) {
    return parent_ids[id];
}
auto& err(excid_t& id) {
    return err_ids[id];
}

// Add ids.
excid_t add_type(const char* id) {
    vlib::array<char*, ullong>::append(type_ids, type_ids_len, type_ids_cap, (char*) id, 4);
    return type_ids_len - 1;
}
excid_t add_parent(const char* id) {
    vlib::array<char*, ullong>::append(parent_ids, parent_ids_len, parent_ids_cap, (char*) id, 4);
    return parent_ids_len - 1;
}
excid_t add_err(const char* id) {
    vlib::array<char*, ullong>::append(err_ids, err_ids_len, err_ids_cap, (char*) id, 4);
    return err_ids_len - 1;
}


// Exception type.
/* 	@docs {
	@chapter: exceptions
	@title: Exception
	@description:
		Exception type.
 
        Define preprocessor variable `vlib_enable_trace` to enable a stacktrace.
        Define preprocessor variable `vlib_trace_depth` to set a max stacktrace depth, the default is 32.
        The stacktrace only works properly when the program is compiled without optimization.
	@usage:
        #include <vlib/types.h>
		vlib::Exception x (...);
} */
struct Exception {

// Private:
private:

	// ---------------------------------------------------------
	// Aliases.

	using 			This = 			Exception;
	using 			Length = 		ullong;

    // ---------------------------------------------------------
    // Static attributes.
    static constexpr uint   m_increaser = 4;
    
	// ---------------------------------------------------------
	// Attributes.
    
    Length          m_type_id;
	char* 			m_type;
	Length			m_type_len;
    Length          m_parent_id;
	char* 			m_parent;
	Length 			m_parent_len;
    Length          m_err_id;
	char* 			m_err;
	Length 			m_err_len;
    StackTrace      m_trace;
// #if vlib_enable_trace == true
//     Loc*            m_locs;
//     Length            m_locs_len;
// #endif

// Public:
public:

	// ---------------------------------------------------------
	// Constructors.

	// Default constructor.
	Exception() :
    m_type_id(internal::npos),
	m_type(nullptr),
	m_type_len(0),
    m_parent_id(internal::npos),
	m_parent(nullptr),
	m_parent_len(0),
    m_err_id(internal::npos),
	m_err(nullptr),
	m_err_len(0)
    {
#if vlib_enable_trace == true
        m_trace.init();
#endif
    }

    // Constructor from ids.
    Exception (
        const Length& type_id,
        const Length& parent_id,
        const Length& err_id
        // #if vlib_enable_trace == true
        //        ,const Loc& loc = Loc::get()
        // #endif
    ) :
    m_type_id(type_id),
    m_type(nullptr),
    m_type_len(0),
    m_parent_id(parent_id),
    m_parent(nullptr),
    m_parent_len(0),
    m_err_id(err_id),
    m_err(nullptr),
    m_err_len(0)
    {
#if vlib_enable_trace == true
        m_trace.init();
#endif
    }
    
	// Constructor from const char* err.
	Exception (
		const char* type,
		const char* parent,
		const char* err
        // #if vlib_enable_trace == true
        //        ,const Loc& loc = Loc::get()
        // #endif
	) :
    m_type_id(internal::npos),
	m_type(nullptr),
	m_type_len(0),
    m_parent_id(internal::npos),
	m_parent(nullptr),
	m_parent_len(0),
    m_err_id(internal::npos),
	m_err(nullptr),
    m_err_len(0)
	{
		Length len;
		if (type) {
			len = vlib::len(type);
			vlib::array<char, Length>::alloc(m_type, len);
			vlib::array<char, Length>::copy(m_type, type, len);
			m_type[len] = '\0';
		}
		if (parent) {
			len = vlib::len(parent);
			vlib::array<char, Length>::alloc(m_parent, len);
			vlib::array<char, Length>::copy(m_parent, parent, len);
			m_parent[len] = '\0';
		}
		if (err) {
			len = vlib::len(err);
			vlib::array<char, Length>::alloc(m_err, len);
			vlib::array<char, Length>::copy(m_err, err, len);
			m_err[len] = '\0';
		}
#if vlib_enable_trace == true
        m_trace.init();
#endif
	}

	// Constructor from String err.
	template <typename String>
	Exception (
		const char* type,
		const char* parent,
		const String& err
	) :
    m_type_id(internal::npos),
	m_type(nullptr),
	m_type_len(0),
    m_parent_id(internal::npos),
	m_parent(nullptr),
	m_parent_len(0),
    m_err_id(internal::npos),
	m_err(nullptr),
    m_err_len(0)
	{
		Length len;
		if (type) {
			len = vlib::len(type);
			vlib::array<char, Length>::alloc(m_type, len);
			vlib::array<char, Length>::copy(m_type, type, len);
			m_type[len] = '\0';
		}
		if (parent) {
			len = vlib::len(parent);
			vlib::array<char, Length>::alloc(m_parent, len);
			vlib::array<char, Length>::copy(m_parent, parent, len);
			m_parent[len] = '\0';
		}
		if (err.m_arr) {
			vlib::array<char, Length>::alloc(m_err, err.m_len);
			vlib::array<char, Length>::copy(m_err, err.m_arr, err.m_len);
			m_err[err.m_len] = '\0';
		}
#if vlib_enable_trace == true
        m_trace.init();
#endif
	}

	// Constructor from String&& err.
	template <typename String>
	Exception (
		const char* type,
		const char* parent,
		String&& err
	) :
    m_type_id(internal::npos),
	m_type(nullptr),
	m_type_len(0),
    m_parent_id(internal::npos),
    m_parent(nullptr),
	m_parent_len(0),
    m_err_id(internal::npos),
	m_err(err.data()),
    m_err_len(err.len())
	{
		Length len;
		if (type) {
			len = vlib::len(type);
			vlib::array<char, Length>::alloc(m_type, len);
			vlib::array<char, Length>::copy(m_type, type, len);
			m_type[len] = '\0';
		}
		if (parent) {
			len = vlib::len(parent);
			vlib::array<char, Length>::alloc(m_parent, len);
			vlib::array<char, Length>::copy(m_parent, parent, len);
			m_parent[len] = '\0';
		}
        err.data() = nullptr;
#if vlib_enable_trace == true
        m_trace.init();
#endif
	}

	// Copy constructor.
	Exception (const This& obj) :
    m_type_id(obj.m_type_id),
	m_type(nullptr),
	m_type_len(0),
    m_parent_id(obj.m_parent_id),
	m_parent(nullptr),
	m_parent_len(0),
    m_err_id(obj.m_err_id),
	m_err(nullptr),
    m_err_len(0),
    m_trace(obj.m_trace)
	{
		Length capacity;
		if (obj.m_type) {
			capacity = 0;
			vlib::array<char, Length>::copy(m_type, m_type_len, capacity, obj.m_type, obj.m_type_len, obj.m_type_len);
		}
		if (obj.m_parent) {
			capacity = 0;
			vlib::array<char, Length>::copy(m_parent, m_parent_len, capacity, obj.m_parent, obj.m_parent_len, obj.m_parent_len);
		}
		if (obj.m_err) {
			capacity = 0;
			vlib::array<char, Length>::copy(m_err, m_err_len, capacity, obj.m_err, obj.m_err_len, obj.m_err_len);
		}
	}

	// Move constructor.
	constexpr
	Exception (This&& obj) :
    m_type_id(obj.m_type_id),
	m_type(obj.m_type),
	m_type_len(obj.m_type_len),
    m_parent_id(obj.m_parent_id),
	m_parent(obj.m_parent),
	m_parent_len(obj.m_parent_len),
    m_err_id(obj.m_err_id),
	m_err(obj.m_err),
    m_err_len(obj.m_err_len),
    m_trace(obj.m_trace)
	{
		obj.m_type = nullptr;
		obj.m_parent = nullptr;
		obj.m_err = nullptr;
	}

	// Destructor.
	constexpr
	~Exception () {
		delete[] m_type;
		delete[] m_parent;
		delete[] m_err;
	}

	// ---------------------------------------------------------
	// Assignment operators.

	// Copy assignment operator.
	constexpr
	auto&	operator =(const This& obj) {
		Length capacity;
        m_type_id = obj.m_type_id;
        if (obj.m_type) {
            vlib::array<char, Length>::copy(m_type, m_type_len, capacity, obj.m_type, obj.m_type_len, obj.m_type_len);
        }
        m_parent_id = obj.m_parent_id;
        if (obj.m_parent) {
            vlib::array<char, Length>::copy(m_parent, m_parent_len, capacity, obj.m_parent, obj.m_parent_len, obj.m_parent_len);
        }
        m_err_id = obj.m_err_id;
        if (obj.m_err) {
            vlib::array<char, Length>::copy(m_err, m_err_len, capacity, obj.m_err, obj.m_err_len, obj.m_err_len);
        }
        m_trace = obj.m_trace;
		return *this;
	}

	// Move assignment operator.
	constexpr
	auto&	operator =(This&& obj) {
		Length capacity;
        m_type_id = obj.m_type_id;
		vlib::array<char, Length>::swap(m_type, m_type_len, capacity, obj.m_type, obj.m_type_len, obj.m_type_len);
        m_parent_id = obj.m_parent_id;
		vlib::array<char, Length>::swap(m_parent, m_parent_len, capacity, obj.m_parent, obj.m_parent_len, obj.m_parent_len);
        m_err_id = obj.m_err_id;
		vlib::array<char, Length>::swap(m_err, m_err_len, capacity, obj.m_err, obj.m_err_len, obj.m_err_len);
        m_trace = obj.m_trace;
		return *this;
	}

	// ---------------------------------------------------------
	// Functions.

	// Type.
    auto& type_id() const {
        return m_type_id;
    }
    const char* type() const {
        if (m_type == nullptr && m_type_id < type_ids_len) {
            return type_ids[m_type_id];
        }
        return m_type;
    }
	
	// Parent.
    auto& parent_id() const {
        return m_parent_id;
    }
    const char* parent() const {
        if (m_parent == nullptr && m_parent_id < parent_ids_len) {
            return parent_ids[m_parent_id];
        }
        return m_parent;
    }
    
	// Message.
    auto& err_id() const {
        return m_err_id;
    }
    const char* err() const {
        if (m_err == nullptr && m_err_id < err_ids_len) {
            return err_ids[m_err_id];
        }
        return m_err;
    }
    
    // Trace.
    char* trace() const {
        return m_trace.trace(2);
    }
	
    
    // Add loc.
    // void add_loc(
    //        #if vlib_enable_trace == true
    //            const Loc& loc
    //        #endif
    //    ) {
    //        #if vlib_enable_trace == true
    //            Length capacity = m_locs_len;
    //            vlib::array<Loc, Length>::append(m_locs, m_locs_len, capacity, loc, m_increaser);
    //        #endif
    // }
    
    
    
	// Rethrow.
    // Deprectaed since it casts the derived exception class to Exception, use add_loc instead.
    // void rethrow(
 //        #if vlib_enable_trace == true
 //            const Loc& loc
 //        #endif
 //    ) {
 //        #if vlib_enable_trace == true
 //            Length capacity = m_locs_len;
 //            vlib::array<Loc, Length>::append(m_locs, m_locs_len, capacity, loc, m_increaser);
 //        #endif
 //        throw Exception(move(*this));
    // }

	// Dump an exception.
	void dump();

	//
};
}; 		// End namespace exceptions.
}; 		// End namespace vlib.
#endif 	// End header.
