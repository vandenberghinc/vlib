/*
 Author: Daan van den Bergh
 Copyright: © 2022 Daan van den Bergh.
 */

// Header.
#ifndef VLIB_STACKTRACE_H
#define VLIB_STACKTRACE_H

// Includes.
#include <signal.h>
#include <execinfo.h>
#include <cxxabi.h>
#include <dlfcn.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif

// Trace depth.
#ifndef vlib_trace_depth
#define vlib_trace_depth 32
#endif

#include <execinfo.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <iostream>
#include <zconf.h>
#include "regex"


// Namespace vlib.
namespace vlib {

// Stacktrace.
struct StackTrace {
    
    // Private:
private:
    
    // ---------------------------------------------------------
    // Attributes.
    
    void*   m_stack[vlib_trace_depth];
    uint    m_len;
    
    // Public:
public:
    
    // ---------------------------------------------------------
    // Constructors.
    
    // Default constructor.
    constexpr
    StackTrace()
    {}
    
    // ---------------------------------------------------------
    // Functions.
    
    // Initialize.
    void    init() {
        m_len = ::backtrace(m_stack, vlib_trace_depth);
    }
    
    // Address to line.
    // @TODO check answer of Yale Zhang for addr on linux https://stackoverflow.com/questions/4636456/how-to-get-a-stack-trace-for-c-using-gcc-with-line-number-information.
    char*    addr2line(const char* executable, void* addr) const {
        
        // Vars.
        int pid, pipe[2];
        char *location = nullptr;
        
        // Create pipes.
        if (::pipe(pipe) == 0) {
            
            // Child.
            if ((pid = fork()) == 0) {
                
                ::dup2(pipe[1], STDOUT_FILENO);
                ::dup2(pipe[1], STDERR_FILENO);
                
                ::close(pipe[0]);
                
                char straddr[64];
                snprintf(straddr, 64, "%p\n", addr);
                // char cmd[1024];
                // snprintf(cmd, 1024, "addr2line -o %.256s -Cf %p", executable, addr);
                // snprintf(cmd, 1024, "addr2line -C -f -e %.256s %p", executable, addr);
                
                // if (execlp("bash", "bash", "-c", cmd, NULL) == -1) {
                if (execlp("addr2line", "addr2line", "-e", executable, "-Cf", straddr, NULL) == -1) {
                // if (execlp("addr2line", "addr2line", "-e", executable, straddr, NULL) == -1) {
                    printf("addr2line: %s.", ::strerror(errno));
                    ::exit(1);
                }
                
                ::exit(0);
            }
            
            // Parent.
            else if (pid > 0) {
                
                
                // Vars.
                llong bytes = 0;
                char buff [1024] = {0};
                
                // Read.
                if (
                    (bytes = ::read(pipe[0], buff, 1024)) > 0 &&
                    strcmp(buff, "??:0\n") != 0 && // not found.
                    strncmp(buff, "addr2line:", 10) != 0 // error.
                ) {
                    vlib::array<char, ullong>::alloc(location, bytes);
                    ullong len = 0, cap = bytes;
                    vlib::array<char, ullong>::concat(location, len, cap, buff, bytes - 1);
                    location[len] = '\0';
                }
                
            }
            
            // Fork error.
            else {
                dprintf(STDERR_FILENO, "[%s:%i:%s] Error: Fork error.\n", __FILE__, __LINE__, __FUNCTION__);
            }
            
        }
        
        ::close(pipe[0]);
        ::close(pipe[1]);

        return location;
    }
    
    // Get the stacktrace as string.
    //  - The returned char* should still be deleted.
    //  - Must be compiled with "-g" and with "-rdynamic" on linux.
    //  - Does not work correctly when compiled with optimization.
    //  - Requires "addr2line" to be installed to get line numbers.
    //    * Install addr2line with on MacOS with "brew install binutils".
    //    * Install addr2line with on linux with "sudo apt install binutils".
    char*   trace(const ullong& start = 1) const {
        
        // Initialize string.
        char* trace = nullptr;
        ullong trace_len = 0, trace_cap = 100;
        vlib::array<char, ullong>::alloc(trace, trace_cap);
        
        // Get messages.
        char** messages = backtrace_symbols(m_stack, m_len);
        
        // Get executable.
        #if defined(__linux__)
            char executable[1024];
            long executable_len = readlink("/proc/self/exe", executable, 256);
            if(executable_len == -1) {
                dprintf(STDERR_FILENO, "[%s:%i:%s::readlink] Error: %s.\n", __FILE__, __LINE__, __FUNCTION__, ::strerror(errno));
            }
            executable[executable_len] = '\0';
        #elif defined(__APPLE__)
            char executable[1024];
            uint executable_len = 1024;
            if (_NSGetExecutablePath(executable, &executable_len) == -1) {
                dprintf(STDERR_FILENO, "[%s:%i:%s::_NSGetExecutablePath] Error: %s.\n", __FILE__, __LINE__, __FUNCTION__, ::strerror(errno));
            }
        #else
            dprintf(STDERR_FILENO, "[%s:%i:%s] Error: Unsupported OS.\n", __FILE__, __LINE__, __FUNCTION__);
        #endif
        
        // Iterate stack.
        bool add_mangled = true;
        ullong i;
        for (i = start; i < m_len; i++) {
            
            // Vars.
            const char *exec = NULL;
            const char *func = NULL;
            char *clean_func = nullptr, *func_name = nullptr;
            ullong clean_func_len = 0, clean_func_cap = 0, func_name_len = 0, func_name_cap = 0;
            char *location = nullptr;
            ullong location_len = 0;
            void *address = NULL; // offset address used by addr2line.
            
            // Get demangled function name.
            Dl_info info;
            if(dladdr(m_stack[i], &info) == 0) {
                if (i > start) {
                    vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, "\n", 1);
                }
                vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, messages[i], vlib::len(messages[i]));
                continue;
            }
            exec = info.dli_fname;
            char* demangled = abi::__cxa_demangle(info.dli_sname, NULL, NULL, NULL);
            
            // Demangled.
            if (demangled != NULL) {
                func = demangled;
                
                // Clean func.
                /* */
                ullong len = vlib::len(func), index = 0;
                const char* p = func;
                bool is_name = true;
                int template_depth = 0;
                int indent = 0;
                for (; *p != '\0'; ++p) {
                    switch (*p) {
                        case '(':
                            is_name = false;
                            vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, *p);
                            if (index + 1 < len && *(p + 1) != ')') {
                                vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, '\n');
                                indent = 8;
                                while (indent-- >= 0) {
                                    vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, ' ');
                                }
                            }
                            break;
                        case ',':
                            vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, *p);
                            if (template_depth == 0 && index + 1 < len && *(p + 1) != ')') {
                                vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, '\n');
                                indent = 7;
                                while (indent-- >= 0) {
                                    vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, ' ');
                                }
                            }
                            break;
                        case ')':
                            if (index <= 0 || *(p - 1) != '(') {
                                vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, '\n');
                                indent = 3;
                                while (indent-- >= 0) {
                                    vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, ' ');
                                }
                            }
                            vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, *p);
                            break;
                        case '<':
                            ++template_depth;
                            if (is_name) {
                                vlib::array<char, ullong>::append(func_name, func_name_len, func_name_cap, *p);
                            }
                            vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, *p);
                            break;
                        case '>':
                            --template_depth;
                            if (is_name) {
                                vlib::array<char, ullong>::append(func_name, func_name_len, func_name_cap, *p);
                            }
                            vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, *p);
                            break;
                        default:
                            if (is_name) {
                                vlib::array<char, ullong>::append(func_name, func_name_len, func_name_cap, *p);
                            }
                            vlib::array<char, ullong>::append(clean_func, clean_func_len, clean_func_cap, *p);
                            break;
                    }
                    ++index;
                }
                clean_func[clean_func_len] = '\0';
                
                // Mangled.
            } else {
                if (add_mangled) {
                    if (i > start) {
                        vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, "\n", 1);
                    }
                    vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, messages[i], vlib::len(messages[i]));
                }
                continue;
            }
            add_mangled = false;
            
// Linux.
#if defined(__linux__)
            
            /*
            // Vars.
            char symbol_str[64];
            uint symbol_str_len = 0;
            char offset_str[64];
            uint offset_str_len = 0;
            
            // Get the symbol and offset strings.
            char* p = messages[i];
            short mode = 0;
            for (; *p != '\0'; ++p) {
                if (*p == ')') {
                    break;
                } else if (*p == '(') {
                    mode = 1;
                } else if (*p == '+') {
                    mode = 2;
                } else if (mode == 1) {
                    symbol_str[symbol_str_len] = *p;
                    ++symbol_str_len;
                } else if (mode == 2) {
                    offset_str[offset_str_len] = *p;
                    ++offset_str_len;
                }
            }
            symbol_str[symbol_str_len] = '\0';
            offset_str[offset_str_len] = '\0';
            
            // Get offset.
            info = {};
            void* raw_address = NULL;
            sscanf(offset_str, "%p",&address);
            void* obj_file = dlopen(NULL, RTLD_LAZY);
            if (obj_file) {
                raw_address = dlsym(obj_file, symbol_str);
                if(raw_address != NULL && dladdr(raw_address, &info) != 0) {
                    address = ((char*) info.dli_saddr - (char*) info.dli_fbase) + (char*)address;
                } else {
                    address = NULL;
                }
                dlclose(obj_file);
            } else {
                address = NULL;
            }
             */
             
            
            // Get addr2line.
            location = addr2line(executable, m_stack[i]);
            
// Macos.
#elif defined(__APPLE__)
            
            // Get addr2line.
            int images = _dyld_image_count();
            for (int i = 0; i <= images; ++i) {
                address = (char*) info.dli_saddr - _dyld_get_image_vmaddr_slide(i);
                if ((location = addr2line(executable, address)) != nullptr) {
                    break;
                }
            }
            
            
// Unsupported os.
#else
            dprintf(STDERR_FILENO, "[%s:%i:%s] Error: Unsupported operating system.\n", __FILE__, __LINE__, __FUNCTION__);
            if (demangled != NULL) {
                free(demangled);
            }
            if (location != nullptr) {
                delete[] location;
            }
            if (clean_func != nullptr) {
                delete[] clean_func;
            }
            if (func_name != nullptr) {
                delete[] func_name;
            }
            continue;
#endif
            
            // Clean location.
            if (location != nullptr) {
                location_len = vlib::len(location);
                char* clean_location;
                ullong clean_location_len = 0;
                vlib::array<char, ullong>::alloc(clean_location, location_len);
                for (uint i = 0; i < location_len; ++i) {
                    
                    // Remove "/./".
                    if (i >= 2 && location[i] == '/' && location[i-1] == '.' && location[i-2] == '/') {
                        clean_location_len -= 2;
                    }
                    
                    // Remove "/../".
                    else if (i >= 2 && location[i] == '/' && location[i-1] == '.' && location[i-2] == '.' && location[i-2] == '/') {
                        clean_location_len -= 3;
                    }
                    
                    // Append.
                    clean_location[clean_location_len] = location[i];
                    ++clean_location_len;
                    
                }
                clean_location[clean_location_len] = '\0';
                delete[] location;
                location = clean_location;
                location_len = clean_location_len;
            }
            
            // Add to string.
            if (i > start) {
                vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, "\n", 1);
            }
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, vlib::colors::bold.data(), vlib::colors::bold.len());
            if (location != NULL) {
                vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, location, location_len);
            } else {
                vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, exec, vlib::len(exec));
                vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, ":?", 2);
            }
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, ": ", 2);
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, vlib::colors::end.data(), vlib::colors::end.len());
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, "in ", 3);
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, vlib::colors::italic.data(), vlib::colors::italic.len());
            
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, func_name, func_name_len);
            // vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, func, vlib::len(func));
            
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, vlib::colors::end.data(), vlib::colors::end.len());
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, "\n    ", 5);
            
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, clean_func, clean_func_len);
            // vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, func, vlib::len(func));
            
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, " { ... }\n    ", 13);
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, vlib::colors::green.data(), vlib::colors::green.len());
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, "^", 1);
            vlib::array<char, ullong>::concat(trace, trace_len, trace_cap, vlib::colors::end.data(), vlib::colors::end.len());
            
            // Free.
            if (demangled != NULL) {
                free(demangled);
            }
            if (location != nullptr) {
                delete[] location;
            }
            if (clean_func != nullptr) {
                delete[] clean_func;
            }
            if (func_name != nullptr) {
                delete[] func_name;
            }
            
        }
        
        // Free.
        free(messages);
        
        // Null terminate and return.
        if (trace_len == 0) {
            delete[] trace;
            return nullptr;
        }
        trace[trace_len] = '\0';
        return trace;
    }
    
};

// ---------------------------------------------------------
// End.

// Stacktrace handler.
// Dumps a stacktrace and then exits the program with status 1.
void    stacktrace_handler(int sig) {
    printf("%sError%s: %s [Signal %i].\n", colors::red.data(), colors::end.data(), ::strerror(sig), sig);
    StackTrace stack_trace;
    stack_trace.init();
    char* trace = stack_trace.trace(1);
    if (trace != nullptr) {
        printf("%s\n", trace);
        delete[] trace;
    }
    ::exit(1);
}

};         // End namespace vlib.
#endif     // End header.
