# Exceptions
Used to throw exceptions with a traceback.

## Types.
The following types are included into the `vlib` namespace. <br/>
- `Loc` <br/>
- `Exception` <br/>
