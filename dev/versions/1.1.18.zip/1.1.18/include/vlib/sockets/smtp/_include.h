/*
 Author: Daan van den Bergh
 Copyright: © 2022 Daan van den Bergh.
*/

// Local includes.
#include "mail.h"
#include "client.h"
