// Author: Daan van den Bergh
// Copyright: © 2022 Daan van den Bergh.

// Header.
#ifndef VLIB_STACKTRACE_2_H
#define VLIB_STACKTRACE_2_H

#include <iostream>
#include <dlfcn.h>
// #include <link.h>
#include <execinfo.h>
#include <mach-o/dyld.h>

// Namespace vlib.
namespace vlib {

// Function to resolve address to function name and line number
void resolveAddress(const void* address, Dl_info& info) {
    if (dladdr(address, &info) != 0) {
        std::cout << "Function: " << info.dli_sname << std::endl;

        // Load the executable to get the line number
        void* handle = dlopen(info.dli_fname, RTLD_NOW);
        if (handle != nullptr) {
            // Get the base address of the loaded executable
            // const uintptr_t baseAddress = (uintptr_t)dlsym(handle, "_mh_execute_header");
            const uintptr_t baseAddress = (uintptr_t)dlsym(handle, "_mh_execute_header");

            // Calculate the relative address within the executable
            const uintptr_t relativeAddress = (uintptr_t)address - baseAddress;

            // Use backtrace_symbols_fd to resolve the line number
            char cmd[512];
            // snprintf(cmd, sizeof(cmd), "atos -o %s -l %llu %llx", info.dli_fname, relativeAddress, baseAddress);
            snprintf(cmd, sizeof(cmd), "atos -o %s -l %p %p", info.dli_fname, (void*)relativeAddress, (void*)baseAddress);
            printf("%s\n", cmd);
            FILE* output = popen(cmd, "r");
            if (output != nullptr) {
                char line[512];
                if (fgets(line, sizeof(line), output) != nullptr) {
                    std::cout << "Line: " << line;
                }
                pclose(output);
            }

            dlclose(handle);
        }
    }
}

int stacktrace_test() {
    // Obtain the address using backtrace or any other means
    void* addresses[10];
    int numAddresses = backtrace(addresses, 10);

    // Iterate over the addresses
    for (int i = 0; i < numAddresses; ++i) {
        Dl_info info;
        resolveAddress(addresses[i], info);
    }

    return 0;
}

};         // End namespace vlib.
#endif     // End header.
