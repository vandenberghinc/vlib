// Author: Daan van den Bergh
// Copyright: © 2022 Daan van den Bergh.

// Header.
#ifndef VLIB_STACKTRACE_TEST_H
#define VLIB_STACKTRACE_TEST_H

// Includes.
#include <bfd.h>
#if defined(__APPLE__)
    #include <mach-o/dyld.h>
#else
    #include <link.h>
#endif

// Namespace vlib.
namespace vlib {

// ---------------------------------------------------------
// Stacktrace.
// Sources: https://github.com/certik/stacktrace

struct StackTraceTest {
    
    // ---------------------------------------------------------
    // Attributes.
    
    // ---------------------------------------------------------
    // Constructor.
    
    // ---------------------------------------------------------
    // Functions.
    
    // Dump (TMP FUNC).
    static
    void    dump() {
        
        // Structs.
        struct StackTraceEntry {
            
            // Address.
            bfd_vma addr;
            bfd_vma offset_addr;
            
            // Path.
            char*   path = nullptr;
            uint    path_len = 0;
            uint    path_cap = 0;
            
            // Line.
            int     line;
            
        };
        
        // Find offset address lambda function.
        #if defined(__APPLE__)
        auto find_offset_address = [](const void* address, void*_data) {
            
            // Vars.
            struct StackTraceEntry *data = (struct StackTraceEntry *)_data;
            const mach_header* header;
            intptr_t slide;
            const char* image_name;

            // Iterate through all loaded images
            for (uint32_t i = 0; i < _dyld_image_count(); ++i) {
                header = _dyld_get_image_header(i);
                slide = _dyld_get_image_vmaddr_slide(i); //_dyld_get_image_slide(i);
                image_name = _dyld_get_image_name(i);

                // Calculate the base address of the current module
                uintptr_t baseAddress = reinterpret_cast<uintptr_t>(header) + slide;

                // Check if the target address falls within the current module
                if (reinterpret_cast<uintptr_t>(address) >= baseAddress &&
                    reinterpret_cast<uintptr_t>(address) < baseAddress + header->sizeofcmds) {
                    data->offset_addr = (bfd_vma) ((char*)address - baseAddress);
                    uint len = vlib::len<uint>(image_name);
                    vlib::array<char, uint>::copy(data->path, data->path_len, data->path_cap, image_name, len, len);
                    return true;
                }
            }
            return false;
        };
        /*auto find_shared_lib = [](void *_data) {
            struct StackTraceEntry *data = (struct StackTraceEntry *)_data;
            uint32_t imageCount = _dyld_image_count();
            for (uint32_t i = 0; i < imageCount; i++) {
                const struct mach_header* header = _dyld_get_image_header(i);
                const char* imageName = _dyld_get_image_name(i);
                if (header) {
                    // uintptr_t headerAddress = (uintptr_t)header;
                    // printf("%i VS %i\n", data->addr, (bfd_vma) headerAddress);
                    // if (data->addr >= headerAddress && data->addr < headerAddress + header->sizeofcmds) {
                        
                    uintptr_t imageStart = (uintptr_t) header;
                    uintptr_t imageEnd = imageStart + header->sizeofcmds + header->ncmds;
                    // printf("%i | %i | %i\n", imageStart, (uintptr_t)data->addr, imageEnd);
                    if ((uintptr_t)data->addr >= imageStart && (uintptr_t)data->addr <= imageEnd) {
                    
                        data->offset_addr = data->addr - _dyld_get_image_vmaddr_slide(i);
                        uint len = vlib::len<uint>(imageName);
                        vlib::array<char, uint>::copy(data->path, data->path_len, data->path_cap, imageName, len, len);
                        data->shared = true;
                        printf("FOUND!");
                        return true;
                    }
                }
            }
            return false;
        };*/
        #else
        auto find_shared_lib = [](struct dl_phdr_info *info, size_t size, void *_data) {
            struct StackTraceEntry *data = (struct StackTraceEntry *)_data;
            for (int i=0; i < info->dlpi_phnum; i++) {
                if (info->dlpi_phdr[i].p_type == PT_LOAD) {
                    ElfW(Addr) min_addr = info->dlpi_addr + info->dlpi_phdr[i].p_vaddr;
                    ElfW(Addr) max_addr = min_addr + info->dlpi_phdr[i].p_memsz;
                    if (data->addr >= min_addr && data->addr < max_addr) {
                        data->offset_addr = data->addr - info->dlpi_addr;
                        uint len = vlib::len<uint>(info->dlpi_name);
                        vlib::array<char, uint>::copy(data->path, data->path_len, data->path_cap, info->dlpi_name, len, len);
                        data->shared = true;
                        return true;
                    }
                }
            }
            return false;
        };
        #endif
        
        // Vars.
        int max_stack = 128, len = 0;
        void* callstack[max_stack];
        char executable[1024];
        
        // Get backtrace.
        len = ::backtrace(callstack, max_stack);
        
        // Get executable.
        #if defined(__linux__)
            long executable_len = readlink("/proc/self/exe", executable, 256);
            if(executable_len == -1) {
                dprintf(STDERR_FILENO, "[%s:%i:%s::readlink] Error: %s.\n", __FILE__, __LINE__, __FUNCTION__, ::strerror(errno));
            }
            executable[executable_len] = '\0';
        #elif defined(__APPLE__)
            uint executable_len = 1024;
            if (_NSGetExecutablePath(executable, &executable_len) == -1) {
                dprintf(STDERR_FILENO, "[%s:%i:%s::_NSGetExecutablePath] Error: %s.\n", __FILE__, __LINE__, __FUNCTION__, ::strerror(errno));
            }
        #else
            dprintf(STDERR_FILENO, "[%s:%i:%s] Error: Unsupported OS.\n", __FILE__, __LINE__, __FUNCTION__);
        #endif
        
        // Iterate.
        for (int i = 0; i < len; ++i) {
            
            // Vars.
            StackTraceEntry match_data {
                .addr = (bfd_vma) callstack[i],
            };
            
            // Find shared lib.
            #if defined(__APPLE__)
            if (!find_offset_address(callstack[i], &match_data)) {
            #else
            if (!dl_iterate_phdr(find_shared_lib, &match_data)) {
            #endif
                dprintf(STDERR_FILENO, "[%s:%i:%s] Error: Unable to find address \"%p\" in any of the loaded libraries.\n", __FILE__, __LINE__, __FUNCTION__, callstack[i]);
                // return ;
            }
                
            
            
        }
        
    }
    
    
    
    
};

};         // End namespace vlib.
#endif     // End header.
