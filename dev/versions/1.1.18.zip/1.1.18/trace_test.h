// Author: Daan van den Bergh
// Copyright: © 2022 Daan van den Bergh.

// Header.
#ifndef VLIB_STACKTRACE_TEST2_H
#define VLIB_STACKTRACE_TEST2_H

// Includes.
#include <iostream>
#include <execinfo.h>

#include <dlfcn.h>
#include <dlfcn.h>

// #define PACKAGE "libgrive" /* dummy to keep <bfd.h> happy */
// #include <bfd.h>
// #include <bfdlink.h>
#if defined(__APPLE__)
    #include <mach-o/dyld.h>
#else
    #include <link.h>
#endif

// Namespace vlib.
namespace vlib {

struct StackTrace2 {
    
// Private.
private:
    
    // ---------------------------------------------------------
    // Structs.
    
    // Structure to store stacktrace entry information
    struct StackTraceEntry {
        void*                   addr;           // address.
        void*                   offset_addr;    // offset address.
        internal::BaseString    func;           // function name.
        internal::BaseString    path;           // binary path.
        internal::BaseString    line_number;    // line number as string.
        internal::BaseString    line;           // line data of the line number.
    };
    
    // Structure to store library information
    struct LibraryInfo {
        int                     image;          // image index (MacOS).
        void*                   addr;           // address.
        internal::BaseString    path;           // binary path.
    };
    
    // ---------------------------------------------------------
    // Definitions.
    
    using Libraries = internal::BaseArray<LibraryInfo, ullong>;
    
    // ---------------------------------------------------------
    // Attributes.
    
    void**  m_stack;
    uint    m_len;
    
    // ---------------------------------------------------------
    // Private functions.
    
    // Retrieve the current executable and the loaded library information.
    Libraries get_libs() {
        Libraries libs;
        
        // Apple.
        #if defined(__APPLE__)
        
        uint numImages = _dyld_image_count();
        for (uint i = 0; i <= numImages; ++i) {
            const struct mach_header* header = _dyld_get_image_header(i);
            if (header != NULL) {
                libs.append(LibraryInfo{
                    .image = (int) i,
                    // .addr = (void*)(uintptr_t)header,
                    .addr = (void*)header,
                    .path = _dyld_get_image_name(i),
                });
            }
        }
        
        // Linux.
        #else
        
        // Iteration callback.
        auto linux_callback = [](struct dl_phdr_info* info, size_t size, void* data) {
            Libraries* libs = (Libraries*) data;
            if (info->dlpi_addr != 0 && info->dlpi_name != nullptr) {
                libs->append(LibraryInfo{
                    .image = -1,
                    .addr = (void*) info->dlpi_addr,
                    .path = info->dlpi_name,
                });
            }
            return 0;
        };
        
        // Add local executable to the libs.
        Dl_info info;
        if (dladdr((void*)get_libs, &info) != 0) {
            libs.append(LibraryInfo{
                .image = -1,
                .addr = (void*) info.dli_fbase,
                .path = info.dli_fname,
            });
        }
        
        // Iterate.
        dl_iterate_phdr(linux_callback, &libs);
        
        #endif
        
        return libs;
    }
    
    // Resolve a path and line number for a stacktrace entry.
    void resolve_entry(
        StackTraceEntry& entry,
        const LibraryInfo& lib
    ) {
        
        // Vars.
        int pid, pipe[2];
        bool use_addr2line = true;
        
        // Create pipes.
        if (::pipe(pipe) == 0) {
            
            // Child.
            if ((pid = fork()) == 0) {
                
                // Dup.
                ::dup2(pipe[1], STDOUT_FILENO);
                ::dup2(pipe[1], STDERR_FILENO);
                
                // Close.
                ::close(pipe[0]);
                
                // Command.
                char cmd[1024];
                if (use_addr2line) {
                    // snprintf(cmd, sizeof(cmd), "addr2line -e %s.dSYM/Contents/Resources/DWARF/buildX %p", lib.path.c_str(), entry.offset_addr);
                    snprintf(cmd, sizeof(cmd), "addr2line -e %s %p", lib.path.c_str(), entry.offset_addr);
                } else {
                    snprintf(cmd, sizeof(cmd), "atos -o %s %p", lib.path.c_str(), entry.offset_addr);
                }
                
                errno = 0;
                if (execlp("bash", "bash", "-c", cmd, NULL) == -1) {
                    printf("addr2line: %s [%i].", ::strerror(errno), errno); // keep as addr2line err for err detection.
                    ::exit(1);
                }
                
                ::exit(0);
            }
            
            // Parent.
            else if (pid > 0) {
                
                
                // Vars.
                internal::BaseString buff;
                buff.resize(1024);
                llong bytes = 0;
                char straddr[128];
                snprintf(straddr, 128, "%p\n", entry.offset_addr);
                
                // Read.
                bytes = ::read(pipe[0], buff.m_arr, buff.m_cap);
                buff.m_len = bytes;
                
                // Read.
                if (
                    bytes > 0 &&
                    buff != "??:0\n" &&                 // not found for addr2line (macos).
                    buff != "??:?\n" &&                 // not found for addr2line (linux).
                    buff != straddr &&                  // not found for atos.
                    !buff.eq_first("addr2line:", 10)    // error.
                    ) {
                        
                        // Close pipes.
                        ::close(pipe[0]);
                        ::close(pipe[1]);
                        
                        // Slice path and line.
                        int len = (int) bytes;
                        int path_start = 0, line_start = 0, line_len = 0;
                        if (use_addr2line) {
                            for (int i = len - 1; i > 0; --i) {
                                switch (buff[i]) {
                                    case ':':
                                        line_start = i + 1;
                                        break;
                                    default:
                                        continue;
                                }
                                break;
                            }
                            line_len = len - line_start - 1;
                        } else {
                            for (int i = len - 1; i > 0; --i) {
                                switch (buff[i]) {
                                    case ':':
                                        line_start = i + 1;
                                        continue;
                                    case '(':
                                        path_start = i + 1;
                                        break;
                                    default:
                                        continue;
                                }
                                break;
                            }
                            line_len = len - line_start - 2;
                        }
                        
                        // No delimiter found.
                        if (line_start == 0) {
                            return ;
                        }
                        
                        // Set.
                        entry.path = internal::BaseString(buff.m_arr + path_start, line_start - path_start - 1);
                        entry.line_number = internal::BaseString(buff.m_arr + line_start, line_len);
                        
                        // Clean ./ from line.
                        internal::BaseString cleaned;
                        uint index = 0;
                        for (auto& c: entry.path) {
                            if (c == '/' && index >= 2 && entry.path.m_arr[index - 1] == '.' && entry.path.m_arr[index - 2] == '/') {
                                cleaned.m_len -= 2;
                            }
                            cleaned.append(c);
                            ++index;
                        }
                        entry.path = cleaned;
                        return ;
                        
                    }
                
                // Read in error.
                else {
                    // printf("READ ERR\n");
                    // if (bytes > 0) {
                    //     printf("%s\n", buff);
                    // }
                }
                
            }
            
            // Fork error.
            else {
                dprintf(STDERR_FILENO, "[%s:%i:%s] Error: Fork error.\n", __FILE__, __LINE__, __FUNCTION__);
            }
            
            // Close.
            ::close(pipe[0]);
            ::close(pipe[1]);
        }
        
    }
    
    // Resolve line data for a stacktrace entry.
    // Should be called after "resolve_entry()".
    void resolve_line_data(
        StackTraceEntry& entry,
        const internal::BaseString& prev_func
    ) {
        
        // When line number is found.
        if (entry.line_number != "?") {
            
            // Load data.
            internal::BaseString buff;
            vlib::load(entry.path.c_str(), buff.m_arr, buff.m_len);
            
            // Path found.
            if (buff.m_arr != nullptr) {
                
                // Set buff cap.
                buff.m_cap = buff.m_len;
                
                // Convert line number.
                ullong line_number = strtoull(entry.line_number.c_str(), NULL, 10);
                
                // One line back to get the correct line.
                line_number -= 1;
                
                // Iterate lines.
                internal::BaseString line_data;
                bool stop = false;
                ullong index = 0, line_start = 0, iter_line = 1;
                for (auto& c: buff) {
                    switch (c) {
                        case '\n':
                            if (iter_line == line_number) {
                                line_data = internal::BaseString(buff.m_arr + line_start, index - line_start);
                                stop = true;
                                break;
                            }
                            line_start = index + 1;
                            ++iter_line;
                            break;
                        default:
                            break;
                    }
                    ++index;
                    if (stop) { break; }
                }
                
                // Remove whitespace.
                bool whitespace = true;
                entry.line.m_len = 0;
                for (auto& c: line_data) {
                    if (whitespace) {
                        if (c != ' ') {
                            entry.line.append(c);
                            whitespace = false;
                        }
                    } else {
                        entry.line.append(c);
                    }
                }
                
                // Reset line data when the previous func is not in the current line, but it its defined.
                if (prev_func.m_len != 0 && strstr(entry.line.m_arr, prev_func.m_arr) == NULL) {
                    entry.line.m_len = 0;
                }
                
            }
            
        }
    }
    
    // Resolve a stacktrace.
    StackTraceEntry resolve(
        void* addr,
        const Libraries& libs,
        const internal::BaseString& prev_func
    ) {
        
        // Iterate over the loaded libraries
        for (const auto& lib : libs) {
            
            // Skip.
            if (lib.path.m_len == 0) {
                continue;
            }
            
            // Check if the address falls within the library's range
            if ((uintptr_t) addr >= (uintptr_t) lib.addr) {
                Dl_info info;
                if (dladdr((void*) addr, &info) != 0 && info.dli_fname != nullptr) {
                    
                    // Check if the symbol is defined in the library.
                    // And the mangled function name is found.
                    if (info.dli_fbase == lib.addr && info.dli_sname != NULL) {
                        
                        // Demangle name
                        char* demangled = abi::__cxa_demangle(info.dli_sname, NULL, NULL, NULL);
                        internal::BaseString func;
                        if (demangled == NULL) {
                            func = info.dli_sname;
                        } else {
                            func = demangled;
                            free(demangled);
                        }
                        func.m_arr[func.m_len] = '\0';
                        
                        // Offset address.
                        //
                        // MacOS.
#if defined(__APPLE__)
                        void* offset_addr = (void*) ((uintptr_t) addr - _dyld_get_image_vmaddr_slide(lib.image));
                        //
                        // Linux.
#else
                        void* offset_addr = (void*) ((uintptr_t) addr - (uintptr_t) lib.addr);
#endif
                        
                        // Return.
                        StackTraceEntry entry {
                            .addr = addr,
                            .offset_addr = offset_addr,
                            .func = func,
                            .path = lib.path,
                            .line_number = "?",
                        };
                        resolve_entry(entry, lib);
                        resolve_line_data(entry, prev_func);
                        return entry;
                    }
                    
                }
            }
        }
        return {};
    }
    
// Public.
public:
    
    // ---------------------------------------------------------
    // Constructors.
    
    StackTrace2() {
        m_stack = new void* [vlib_max_trace];
        m_len = ::backtrace(m_stack, vlib_max_trace);
    }
    
    // ---------------------------------------------------------
    // Functions.
    
    // Get the stacktrace as string.
    // The returned char* should still be deleted.
    // When no trace data is available "nullptr" will be returned.
    char* trace(const int& skip = 1) {
        
        // Vars.
        const int max_trace = 128;
        void* stack[max_trace];
        int len = backtrace(stack, 10);
        internal::BaseString trace, prev_func;
        
        // Get libraries.
        const Libraries libs = get_libs();
        
        // Iterate over the addresses
        for (int i = 0; i < len; ++i) {
            
            // Resolve.
            StackTraceEntry entry = resolve(stack[i], libs, prev_func);
            
            // Skip.
            if (entry.path.m_len == 0) {
                continue;
            }
            
            // Stop.
            if (entry.func == "__libc_start_main") {
                break;
            }
            
            // Set previous function.
            prev_func.m_len = 0;
            for (auto& c: entry.func) {
                if (c == '(') { break; }
                prev_func.append(c);
            }
            prev_func.m_arr[prev_func.m_len] = '\0';
            
            // Concat.
            if (i >= skip) {
                trace << colors::bold.data() << entry.path << ":" << entry.line_number << colors::end.data() <<
                ": in " << entry.func << ":\n";
                if (entry.line.m_len == 0) {
                    trace << "    " << entry.func << "\n";
                } else {
                    trace << "    " << entry.line << "\n";
                }
                trace << "    " << colors::green.data() << "^" << colors::end.data() << "\n";
            }
            
        }
        
        // Remove last newline.
        if (trace.m_len > 0) {
            --trace.m_len;
            trace.m_arr[trace.m_len] = '\0';
        }
        
        // Return.
        char* data = trace.m_arr;
        trace.m_arr = nullptr;
        return data;
        
    }
    
    // Dump the stacktrace.
    void dump(const int& skip = 1) {
        char* data = trace(skip);
        if (data != nullptr) {
            printf("%s\n", data);
            delete[] data;
        } else {
            printf("No stack trace data available.\n");
        }
    }
    
};

};         // End namespace vlib.
#endif     // End header.
